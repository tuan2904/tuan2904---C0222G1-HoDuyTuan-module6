export interface AppUser {
  id?: number;
  username?: number;
  password?: number;
  status?: boolean;
}

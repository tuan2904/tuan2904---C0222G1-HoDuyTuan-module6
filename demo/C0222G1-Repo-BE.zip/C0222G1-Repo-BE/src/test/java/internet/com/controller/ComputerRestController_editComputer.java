package internet.com.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import internet.com.dto.computer_dto.ComputerDTO;
import internet.com.entity.computer.ComputerType;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class ComputerRestController_editComputer {

    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private ObjectMapper objectMapper;

    /**
     * Create by: TuanHD
     * Date Create: 10/08/2022
     * funtion: Create test JUnit 5 edit in computer
     *
     * @throws Exception
     */
    /**
     * this funtion use to test validation of field code more specific is null
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void editComputer_code_19() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode(null);
        computerDTO.setStatus(0);
        computerDTO.setLocation("A111");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Asus");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(1);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this funtion use to test validation of field code more specific is empty
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void editComputer_code_20() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode(" ");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A111");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Asus");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(1);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this funtion use to test validation of field code more specific is containing special character
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void editComputer_code_21() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP000000");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A111");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Asus");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(1);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this funtion use to test validation of field code more specific is min length
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void editComputer_code_22() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("C");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A111");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Asus");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(1);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this funtion use to test validation of field code more specific is max length
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void editComputer_code_23() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP00000000000000000000000000000000000000000000000000000000000000000");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A111");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Asus");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(1);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this function used to test when done successfully
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void editComputer_code_24() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this funtion use to test validation of field code more specific is null
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void editComputer_status_19() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(null);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this function used to test when done successfully
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void editComputer_status_24() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP8888");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this funtion use to test validation of field location more specific is null
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void editComputer_location_19() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation(null);
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this funtion use to test validation of field location more specific is empty
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void editComputer_location_20() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this function use to test the validation of field location more specific is containing special character
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void editComputer_location_21() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A00000");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this function used to test when done successfully
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void editComputer_location_24() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this funtion use to test validation of field StartUsedDate more specific is null
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void editComputer_StartUsedDate_19() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation(null);
        computerDTO.setStartUsedDate(null);
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this funtion use to test validation of field StartUsedDate more specific is empty
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void editComputer_StartUsedDate_20() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation(null);
        computerDTO.setStartUsedDate("");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this function used to test when done successfully
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void editComputer_StartUsedDate_24() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this funtion use to test validation of field Configuration more specific is null
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void editComputer_configuration_19() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration(null);
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this funtion use to test validation of field Configuration more specific is empty
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void editComputer_configuration_20() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this function use to test the validation of field Configuration more specific is min length
     *
     * @author LongNH
     * @Time 15:05 30/06/2022
     */
    @Test
    public void editComputer_configuration_23() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this function used to test when done successfully
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void editComputer_Configuration_24() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this function use to test the validation of field Manufacturer more specific is null
     *
     * @author LongNH
     * @Time 15:00 30/06/2022
     */
    @Test
    public void editComputer_Manufacturer_19() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer(null);
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this function use to test the validation of field Manufacturer more specific is empty
     *
     * @author LongNH
     * @Time 15:00 30/06/2022
     */
    @Test
    public void editComputer_Manufacturer_20() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this function use to test the validation of field Manufacturer more specific is min length
     *
     * @author LongNH
     * @Time 15:05 30/06/2022
     */
    @Test
    public void editComputer_Manufacturer_23() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("a");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this function used to test when done successfully
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void editComputer_Manufacturer_24() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this function use to test the validation of field DeleteStatus more specific is null
     *
     * @author LongNH
     * @Time 15:00 30/06/2022
     */
    @Test
    public void editComputer_DeleteStatus_19() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("a");
        computerDTO.setDeleteStatus(null);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this function used to test when done successfully
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void editComputer_DeleteStatus_24() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this function use to test the validation of field Warranty more specific is null
     *
     * @author LongNH
     * @Time 15:00 30/06/2022
     */
    @Test
    public void editComputer_Warranty_19() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("a");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty(null);

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this function use to test the validation of field Warranty more specific is empty
     *
     * @author LongNH
     * @Time 15:00 30/06/2022
     */
    @Test
    public void editComputer_Warranty_20() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("a");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this function used to test when done successfully
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void editComputer_Warranty_24() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .patch("/computer/edit-computer/2")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }
}
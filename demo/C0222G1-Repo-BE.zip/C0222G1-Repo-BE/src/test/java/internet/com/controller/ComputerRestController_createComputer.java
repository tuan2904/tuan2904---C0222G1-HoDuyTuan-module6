package internet.com.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import internet.com.dto.computer_dto.ComputerDTO;
import internet.com.entity.computer.ComputerType;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class ComputerRestController_createComputer {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    /**
     * Create by: TuanHD
     * Date Create: 10/08/2022
     * funtion: Create test JUnit 5 create in computer
     * @throws Exception
     */

    /**
     * this funtion use to test validation of field code more specific is null
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void createComputer_code_13() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode(null);
        computerDTO.setStatus(0);
        computerDTO.setLocation("A001");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7");
        computerDTO.setManufacturer("Asus");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(1);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                .content(this.objectMapper.writeValueAsString(computerDTO))
                .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this funtion use to test validation of field code more specific is empty
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void createComputer_code_14() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A001");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7");
        computerDTO.setManufacturer("Asus");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(1);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this funtion use to test validation of field code more specific is containing special character
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void createComputer_code_15() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("AP00001");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A001");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7");
        computerDTO.setManufacturer("Asus");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");
        ComputerType computerType = new ComputerType();
        computerType.setId(1);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this funtion use to test validation of field code more specific is min length
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void createComputer_code_16() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("C");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A001");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7");
        computerDTO.setManufacturer("Asus");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(1);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this funtion use to test validation of field code more specific is max length
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void createComputer_code_17() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("C");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A001");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7");
        computerDTO.setManufacturer("Asus");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(1);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this function used to test when done successfully
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void createComputer_code_18() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this funtion use to test validation of field code more specific is null
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void createComputer_status_13() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP0001");
        computerDTO.setStatus(null);
        computerDTO.setLocation("A001");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7");
        computerDTO.setManufacturer("Asus");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this function used to test when done successfully
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void createComputer_status_18() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP8888");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this funtion use to test validation of field location more specific is null
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void createComputer_location_13() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP0001");
        computerDTO.setStatus(0);
        computerDTO.setLocation(null);
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7");
        computerDTO.setManufacturer("Asus");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this funtion use to test validation of field location more specific is empty
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void createComputer_location_14() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP0001");
        computerDTO.setStatus(0);
        computerDTO.setLocation("");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7");
        computerDTO.setManufacturer("Asus");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this function use to test the validation of field location more specific is containing special character
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void createComputer_location_15() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP0001");
        computerDTO.setStatus(0);
        computerDTO.setLocation("B0001");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7");
        computerDTO.setManufacturer("Asus");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this function used to test when done successfully
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void createComputer_location_18() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this funtion use to test validation of field StartUsedDate more specific is null
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void createComputer_StartUsedDate_13() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP0001");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A001");
        computerDTO.setStartUsedDate(null);
        computerDTO.setConfiguration("I7");
        computerDTO.setManufacturer("Asus");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this funtion use to test validation of field StartUsedDate more specific is empty
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void createComputer_StartUsedDate_14() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP0001");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A001");
        computerDTO.setStartUsedDate("");
        computerDTO.setConfiguration("I7");
        computerDTO.setManufacturer("Asus");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this function used to test when done successfully
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void createComputer_StartUsedDate_18() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this funtion use to test validation of field Configuration more specific is null
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void createComputer_Configuration_13() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP0001");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A001");
        computerDTO.setStartUsedDate("12-12-2021");
        computerDTO.setConfiguration(null);
        computerDTO.setManufacturer("Asus");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this funtion use to test validation of field Configuration more specific is empty
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void createComputer_Configuration_15() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP0001");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A001");
        computerDTO.setStartUsedDate("12-12-2021");
        computerDTO.setConfiguration("");
        computerDTO.setManufacturer("Asus");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this function use to test the validation of field Configuration more specific is min length
     *
     * @author LongNH
     * @Time 15:05 30/06/2022
     */
    @Test
    public void createComputer_Configuration_16() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP0001");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A001");
        computerDTO.setStartUsedDate("12-12-2021");
        computerDTO.setConfiguration("I");
        computerDTO.setManufacturer("Asus");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this function use to test the validation of field Configuration more specific is max length
     *
     * @author LongNH
     * @Time 15:05 30/06/2022
     */
    @Test
    public void createComputer_Configuration_17() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP0001");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A001");
        computerDTO.setStartUsedDate("12-12-2021");
        computerDTO.setConfiguration("Iaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        computerDTO.setManufacturer("Asus");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this function used to test when done successfully
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void createComputer_Configuration_18() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }

    /**
     * this function use to test the validation of field Manufacturer more specific is null
     *
     * @author LongNH
     * @Time 15:00 30/06/2022
     */
    @Test
    public void createComputer_Manufacturer_13() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP0001");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A001");
        computerDTO.setStartUsedDate("12-12-2021");
        computerDTO.setConfiguration("I7 32G");
        computerDTO.setManufacturer(null);
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this function use to test the validation of field Manufacturer more specific is empty
     *
     * @author LongNH
     * @Time 15:00 30/06/2022
     */
    @Test
    public void createComputer_Manufacturer_14() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP0001");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A001");
        computerDTO.setStartUsedDate("12-12-2021");
        computerDTO.setConfiguration("I7 32G");
        computerDTO.setManufacturer("");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this function use to test the validation of field Manufacturer more specific is min length
     *
     * @author LongNH
     * @Time 15:05 30/06/2022
     */
    @Test
    public void createComputer_Manufacturer_16() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP0001");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A001");
        computerDTO.setStartUsedDate("12-12-2021");
        computerDTO.setConfiguration("I7 32G");
        computerDTO.setManufacturer("a");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this function use to test the validation of field Manufacturer more specific is max length
     *
     * @author LongNH
     * @Time 15:05 30/06/2022
     */
    @Test
    public void createComputer_Manufacturer_17() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP0001");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A001");
        computerDTO.setStartUsedDate("12-12-2021");
        computerDTO.setConfiguration("I7 32G");
        computerDTO.setManufacturer("a");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this function used to test when done successfully
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void createComputer_Manufacturer_18() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }


    /**
     * this function use to test the validation of field DeleteStatus more specific is null
     *
     * @author LongNH
     * @Time 15:00 30/06/2022
     */
    @Test
    public void createComputer_DeleteStatus_13() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP0001");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A001");
        computerDTO.setStartUsedDate("12-12-2021");
        computerDTO.setConfiguration("I7 32G");
        computerDTO.setManufacturer("");
        computerDTO.setDeleteStatus(null);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this function used to test when done successfully
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void createComputer_DeleteStatus_18() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP009");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("2022-01-01");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }


    /**
     * this function use to test the validation of field Warranty more specific is null
     *
     * @author LongNH
     * @Time 15:00 30/06/2022
     */
    @Test
    public void createComputer_Warranty_13() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP0001");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A001");
        computerDTO.setStartUsedDate("12-12-2021");
        computerDTO.setConfiguration("I7 32G");
        computerDTO.setManufacturer("");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty(null);

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this function use to test the validation of field Warranty more specific is empty
     *
     * @author LongNH
     * @Time 15:00 30/06/2022
     */
    @Test
    public void createComputer_Warranty_15() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP0001");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A001");
        computerDTO.setStartUsedDate("12-12-2021");
        computerDTO.setConfiguration("I7 32G");
        computerDTO.setManufacturer("");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    /**
     * this function used to test when done successfully
     *
     * @author TuanHD
     * @throws Exception
     */
    @Test
    public void createComputer_Warranty_18() throws Exception {
        ComputerDTO computerDTO = new ComputerDTO();
        computerDTO.setCode("CP0099");
        computerDTO.setStatus(0);
        computerDTO.setLocation("A009");
        computerDTO.setStartUsedDate("12/12/2022");
        computerDTO.setConfiguration("I7a");
        computerDTO.setManufacturer("Dell");
        computerDTO.setDeleteStatus(0);
        computerDTO.setWarranty("2 năm");

        ComputerType computerType = new ComputerType();
        computerType.setId(2);
        computerDTO.setComputerType(computerType);

        this.mockMvc
                .perform(MockMvcRequestBuilders
                        .post("/computer/create-computer")
                        .content(this.objectMapper.writeValueAsString(computerDTO))
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andDo(print())
                .andExpect(status().is2xxSuccessful());
    }
}

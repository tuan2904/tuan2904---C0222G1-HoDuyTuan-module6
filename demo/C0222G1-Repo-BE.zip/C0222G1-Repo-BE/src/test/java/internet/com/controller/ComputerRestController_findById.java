package internet.com.controller;

import internet.com.dto.computer_dto.ComputerDTO;
import internet.com.entity.computer.ComputerType;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class ComputerRestController_findById {
    @Autowired
    private MockMvc mockMvc;

    /**
     * Create by: TuanHD
     * Date Create: 10/08/2022
     * funtion: Create test JUnit 5 findbyid in computer
     * @throws Exception
     */
    @Test
    public void findById_id_1() throws Exception {
        this.mockMvc.perform(
                MockMvcRequestBuilders.get("/computer/list/null"))
                .andDo(print())
                .andExpect(status().is4xxClientError());
    }

    @Test
    public void findById_id_4() throws Exception {
        this.mockMvc.perform(
                MockMvcRequestBuilders.get("/computer/list/2"))
                .andDo(print())
                .andExpect(status().is2xxSuccessful())
                .andExpect(jsonPath("id").value(2))
                .andExpect(jsonPath("code").value("CP0000"))
                .andExpect(jsonPath("configuration").value("I7a"))
                .andExpect(jsonPath("deleteStatus").value(0))
                .andExpect(jsonPath("location").value("A009"))
                .andExpect(jsonPath("manufacturer").value("Dell"))
                .andExpect(jsonPath("startUsedDate").value("2021-12-12"))
                .andExpect(jsonPath("status").value(0))
                .andExpect(jsonPath("warranty").value("2 năm"))
                .andExpect(jsonPath("computerType.id").value(1));
    }
}

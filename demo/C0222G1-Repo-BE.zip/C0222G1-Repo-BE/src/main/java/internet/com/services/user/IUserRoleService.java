package internet.com.services.user;

public interface IUserRoleService {

}

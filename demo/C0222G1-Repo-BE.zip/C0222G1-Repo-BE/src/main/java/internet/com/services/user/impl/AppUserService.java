package internet.com.services.user.impl;

import internet.com.services.user.IAppUserService;
import org.springframework.stereotype.Service;

@Service
public class AppUserService implements IAppUserService {


}

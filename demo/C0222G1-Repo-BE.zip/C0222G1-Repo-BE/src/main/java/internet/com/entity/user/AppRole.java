package internet.com.entity.user;

public class AppRole {
}

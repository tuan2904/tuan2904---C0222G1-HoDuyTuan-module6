package internet.com.services.news;

public interface INewsService {
}

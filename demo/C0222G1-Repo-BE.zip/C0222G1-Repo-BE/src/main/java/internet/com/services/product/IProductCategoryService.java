package internet.com.services.product;

public interface IProductCategoryService {
}

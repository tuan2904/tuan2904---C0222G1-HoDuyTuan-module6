package internet.com.dto.game_dto;

public class GameDTO {
}

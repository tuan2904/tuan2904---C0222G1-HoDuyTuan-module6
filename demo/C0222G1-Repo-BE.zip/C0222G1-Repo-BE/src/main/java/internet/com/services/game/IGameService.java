package internet.com.services.game;

public interface IGameService {
}

package internet.com.entity.game;

public class GameCategory {
}

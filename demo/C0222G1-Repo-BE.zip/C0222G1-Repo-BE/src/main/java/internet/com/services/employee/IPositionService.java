package internet.com.services.employee;

public interface IPositionService {
}

package internet.com.services.computer;

import internet.com.entity.computer.Computer;

import java.util.List;

public interface IComputerService {
    Computer findById(Integer id);

    void createComputer(Computer computer);

    void updateComputer(Integer id,Computer computer);

    List<Computer> findAll();
}

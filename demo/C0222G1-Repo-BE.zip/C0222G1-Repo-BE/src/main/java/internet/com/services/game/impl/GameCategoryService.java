package internet.com.services.game.impl;

import internet.com.services.game.IGameCategoryService;

public class GameCategoryService implements IGameCategoryService {
}

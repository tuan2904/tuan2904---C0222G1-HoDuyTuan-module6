package internet.com.services.customer.impl;

import internet.com.services.customer.ICustomerService;

public class CustomerService implements ICustomerService {
}

package internet.com.services.employee.impl;

import internet.com.services.employee.IEmployeeService;

public class EmployeeService implements IEmployeeService {
}

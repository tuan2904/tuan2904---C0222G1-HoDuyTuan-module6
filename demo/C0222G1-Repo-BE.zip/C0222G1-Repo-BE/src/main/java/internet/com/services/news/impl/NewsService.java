package internet.com.services.news.impl;

import internet.com.services.news.INewsService;

public class NewsService implements INewsService {
}

package internet.com.services.payment;

public interface IPaymentService {
}

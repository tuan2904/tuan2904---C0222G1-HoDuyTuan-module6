package internet.com.entity.game;

public class Game {
}

package internet.com.services.product;

public interface IProductService {
}

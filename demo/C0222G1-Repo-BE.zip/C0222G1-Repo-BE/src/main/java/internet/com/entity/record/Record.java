package internet.com.entity.record;

public class Record {
}

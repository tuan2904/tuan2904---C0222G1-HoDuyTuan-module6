package internet.com.services.user.impl;

import internet.com.services.user.IAppRoleService;
import org.springframework.stereotype.Service;


@Service
public class AppRoleService implements IAppRoleService {

}

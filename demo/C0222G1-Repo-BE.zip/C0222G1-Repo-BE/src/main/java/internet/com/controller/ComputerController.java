package internet.com.controller;

import internet.com.dto.computer_dto.ComputerDTO;
import internet.com.entity.computer.Computer;
import internet.com.entity.computer.ComputerType;
import internet.com.services.computer.impl.ComputerService;
import internet.com.services.computer.impl.ComputerTypeService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;


@RestController
@RequestMapping("/computer")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ComputerController {
    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    private ComputerService computerService;
    @Autowired
    private ComputerTypeService computerTypeService;

    /**
     * Create by: TuanHD
     * Date Create: 09/08/2022
     * funtion: Create item in computer
     * @param computerDTO
     * @return
     */
    @PostMapping("/create-computer")
    public ResponseEntity<?> createComputer(@RequestBody @Valid ComputerDTO computerDTO) {
        Computer computer = modelMapper.map(computerDTO, Computer.class);
        computerService.createComputer(computer);
        return new ResponseEntity<>(computer, HttpStatus.CREATED);
    }

    /**
     * Create by: TuanHD
     * Date Create: 09/08/2022
     * funtion: Edit item in computer
     * @param computerDTO
     * @return
     */
    @PatchMapping(value = "/edit-computer/{id}")
    public ResponseEntity<Computer> editComputer(@PathVariable("id") Integer id,@RequestBody @Valid ComputerDTO computerDTO){
        Computer computer = modelMapper.map(computerDTO, Computer.class);
        computerService.updateComputer(id,computer);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * Create by: TuanHD
     * Date Create: 10/08/2022
     * funtion: findById item in computer
     * @param id
     * @return
     */
    @GetMapping(value = "/list/{id}")
    public ResponseEntity<Computer> findById(@PathVariable("id") Integer id){
        Computer computer= computerService.findById(id);
        if (computer == null){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(computer,HttpStatus.OK);
    }


    @GetMapping(value = "/list")
    public ResponseEntity<List<Computer>> getListStudent() {
        computerTypeService.findAll();
        List<Computer> classStudentList = computerService.findAll();

        if (classStudentList.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        System.out.println(classStudentList);
        return new ResponseEntity<>(classStudentList, HttpStatus.OK);
    }


    /**
     * Create by: TuanHD
     * Date Create: 11/08/2022
     * funtion: findAllComputerType item in computerType
     * @return
     */
    @GetMapping(value = "/list/computer-type")
    public ResponseEntity<List<ComputerType>> getListComputerType() {
        List<ComputerType> computerType = computerTypeService.findAll();
        if (computerType.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        System.out.println(computerType);

        return new ResponseEntity<>(computerType, HttpStatus.OK);
    }
}

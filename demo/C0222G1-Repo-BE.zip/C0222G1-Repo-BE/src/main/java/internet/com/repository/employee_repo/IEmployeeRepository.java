package internet.com.repository.employee_repo;

public interface IEmployeeRepository {
}

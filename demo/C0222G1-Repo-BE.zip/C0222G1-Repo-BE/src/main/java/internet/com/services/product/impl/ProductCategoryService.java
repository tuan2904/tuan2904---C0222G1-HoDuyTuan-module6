package internet.com.services.product.impl;

import internet.com.services.product.IProductCategoryService;

public class ProductCategoryService implements IProductCategoryService {
}

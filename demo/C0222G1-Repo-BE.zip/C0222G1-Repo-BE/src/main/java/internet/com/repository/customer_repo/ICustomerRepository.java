package internet.com.repository.customer_repo;

public interface ICustomerRepository {
}

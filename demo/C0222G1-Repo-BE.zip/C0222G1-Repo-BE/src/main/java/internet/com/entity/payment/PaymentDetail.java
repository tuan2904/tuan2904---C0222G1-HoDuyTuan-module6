package internet.com.entity.payment;

public class PaymentDetail {
}

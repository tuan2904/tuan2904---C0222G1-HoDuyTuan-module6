package internet.com.services.customer;

public interface ICustomerService {
}

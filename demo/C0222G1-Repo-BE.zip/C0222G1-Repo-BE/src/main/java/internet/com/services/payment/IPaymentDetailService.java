package internet.com.services.payment;

public interface IPaymentDetailService {
}

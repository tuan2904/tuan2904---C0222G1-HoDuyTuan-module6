package internet.com.repository.news_repo;

public interface INewsRepository {
}

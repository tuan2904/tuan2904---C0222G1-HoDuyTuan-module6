package internet.com.services.game.impl;

import internet.com.services.game.IGameService;

public class GameService implements IGameService {
}

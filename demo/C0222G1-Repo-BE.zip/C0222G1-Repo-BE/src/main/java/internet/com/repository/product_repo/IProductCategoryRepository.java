package internet.com.repository.product_repo;

public interface IProductCategoryRepository {
}

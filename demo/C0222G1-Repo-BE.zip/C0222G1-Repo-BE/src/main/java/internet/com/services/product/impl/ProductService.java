package internet.com.services.product.impl;

import internet.com.services.product.IProductService;

public class ProductService implements IProductService {
}

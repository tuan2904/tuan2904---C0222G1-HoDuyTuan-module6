package internet.com.entity.news;

public class News {
}

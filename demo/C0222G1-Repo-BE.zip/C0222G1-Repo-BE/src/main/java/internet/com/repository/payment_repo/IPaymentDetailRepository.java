package internet.com.repository.payment_repo;

public interface IPaymentDetailRepository {
}

package internet.com.services.payment.impl;

import internet.com.services.payment.IPaymentService;

public class PaymentService implements IPaymentService {
}

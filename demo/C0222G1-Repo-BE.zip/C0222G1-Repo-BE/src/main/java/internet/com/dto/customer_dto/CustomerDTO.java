package internet.com.dto.customer_dto;

public class CustomerDTO {
}

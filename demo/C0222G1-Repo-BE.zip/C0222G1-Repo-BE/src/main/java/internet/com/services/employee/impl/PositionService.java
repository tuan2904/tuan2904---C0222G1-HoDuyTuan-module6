package internet.com.services.employee.impl;

import internet.com.services.employee.IPositionService;

public class PositionService implements IPositionService {
}

package internet.com.services.user.impl;

import internet.com.services.user.IUserRoleService;
import org.springframework.stereotype.Service;

@Service
public class UserRoleService implements IUserRoleService {

}

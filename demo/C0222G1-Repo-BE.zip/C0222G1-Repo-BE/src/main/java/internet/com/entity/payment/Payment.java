package internet.com.entity.payment;

public class Payment {
}

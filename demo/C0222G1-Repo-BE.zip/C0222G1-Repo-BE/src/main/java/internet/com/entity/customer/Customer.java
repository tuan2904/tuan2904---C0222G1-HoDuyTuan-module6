package internet.com.entity.customer;

public class Customer {
}

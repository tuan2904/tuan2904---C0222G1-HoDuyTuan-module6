package internet.com.dto.product_dto;

public class ProductDTO {
}

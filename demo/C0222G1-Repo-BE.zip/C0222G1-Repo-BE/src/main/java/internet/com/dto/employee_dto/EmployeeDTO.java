package internet.com.dto.employee_dto;

public class EmployeeDTO {
}

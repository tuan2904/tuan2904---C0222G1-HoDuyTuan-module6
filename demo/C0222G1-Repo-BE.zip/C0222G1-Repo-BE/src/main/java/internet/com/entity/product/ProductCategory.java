package internet.com.entity.product;

public class ProductCategory {
}

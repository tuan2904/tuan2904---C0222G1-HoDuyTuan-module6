package internet.com.entity.customer;

public class Province {
}

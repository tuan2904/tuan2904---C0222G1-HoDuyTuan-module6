package internet.com.services.employee;

public interface ILevelService {
}

package internet.com.entity.computer;

import javax.persistence.*;
import javax.validation.constraints.*;


@Entity(name = "computer")
public class Computer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(name = "computer_code")
//    @NotBlank(message = "Không được để trống")
//    @Pattern(regexp = "^(CP)[0-9]{4}$", message = "Code phải có dạng CPXXSX")
    private String code;

    @Column(name = "active_status")
    private Integer status;

//    @Pattern(regexp = "^(A)[0-9]{3}$", message = "Vị trí phải có định dạng AXXX")
    @Column
    private String location;

    @Column(name = "start_used_date", columnDefinition = "DATE")
//    @NotNull(message = " không được null, có định dạng là dd/MM/yyyy và phải trước ngày hiện tại")
    private String startUsedDate;

    @Column(name = "configuration")
//    @NotBlank
//    @Min(value = 2, message = "Không được bé hơn 2 ký tự")
//    @Max(value = 30, message = "Không được ghi qua dài,giới hạn 30 ký tự")
    private String configuration;

//    @NotBlank(message = "Không được để trống")
    @Column
    private String manufacturer;

    @Column(name = "delete_status",columnDefinition = "int default 0")
    private Integer deleteStatus;

//    @NotBlank(message = "Không được để trống")
    @Column
    private String warranty;

    @ManyToOne
    @JoinColumn(name = "typeId", referencedColumnName = "id")
    private ComputerType computerType;

    public Computer(Integer id,
                    String code,
                    Integer status,
                    String location,
                    String startUsedDate,
                    String configuration,
                    String manufacturer,
                    Integer deleteStatus,
                    String warranty,
                    ComputerType computerType) {
        this.id = id;
        this.code = code;
        this.status = status;
        this.location = location;
        this.startUsedDate = startUsedDate;
        this.configuration = configuration;
        this.manufacturer = manufacturer;
        this.deleteStatus = deleteStatus;
        this.warranty = warranty;
        this.computerType = computerType;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }


    public String getStartUsedDate() {
        return startUsedDate;
    }

    public void setStartUsedDate(String startUsedDate) {
        this.startUsedDate = startUsedDate;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getDeleteStatus() {
        return deleteStatus;
    }

    public void setDeleteStatus(Integer deleteStatus) {
        this.deleteStatus = deleteStatus;
    }

    public Computer() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Integer getStatus() {
        return status;
    }


    public String getConfiguration() {
        return configuration;
    }

    public void setConfiguration(String configuration) {
        this.configuration = configuration;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getWarranty() {
        return warranty;
    }

    public void setWarranty(String warranty) {
        this.warranty = warranty;
    }

    public ComputerType getComputerType() {
        return computerType;
    }

    public void setComputerType(ComputerType computerType) {
        this.computerType = computerType;
    }


}

package internet.com.entity.employee;

public class Salary {
}

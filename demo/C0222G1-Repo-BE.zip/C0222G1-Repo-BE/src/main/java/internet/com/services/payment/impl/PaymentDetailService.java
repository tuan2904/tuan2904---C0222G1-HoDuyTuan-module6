package internet.com.services.payment.impl;

import internet.com.services.payment.IPaymentDetailService;

public class PaymentDetailService implements IPaymentDetailService {
}

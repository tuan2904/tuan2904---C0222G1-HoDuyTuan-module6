package internet.com.repository.user_repo;

public interface IAppUserRepository {
}

package internet.com.repository.game_repo;

public interface IGameRepository {
}

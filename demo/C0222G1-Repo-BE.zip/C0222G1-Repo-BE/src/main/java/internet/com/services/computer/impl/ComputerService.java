package internet.com.services.computer.impl;

import internet.com.entity.computer.Computer;
import internet.com.repository.computer_repo.IComputerRepository;
import internet.com.services.computer.IComputerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ComputerService implements IComputerService {
    @Autowired
    private IComputerRepository iComputerRepository;
    @Override
    public Computer findById(Integer id) {
        return iComputerRepository.findByIdComputer(id);
    }

    @Override
    public void createComputer(Computer computer) {
    iComputerRepository.createComputer(computer.getCode(),computer.getConfiguration(),computer.getLocation(),
            computer.getManufacturer(),computer.getStartUsedDate(),computer.getStatus(),computer.getWarranty(),computer.getComputerType().getId()
    ,computer.getDeleteStatus());
    }

    @Override
    public void updateComputer(Integer id,Computer computer) {
    iComputerRepository.updateComputer(computer.getCode(),computer.getConfiguration(),computer.getLocation(),
            computer.getManufacturer(),computer.getStartUsedDate(),computer.getStatus(),computer.getWarranty(),computer.getComputerType().getId()
            ,computer.getDeleteStatus(),computer.getId());
    }

    @Override
    public List<Computer> findAll() {
        return iComputerRepository.findAllComputer();
    }
}
